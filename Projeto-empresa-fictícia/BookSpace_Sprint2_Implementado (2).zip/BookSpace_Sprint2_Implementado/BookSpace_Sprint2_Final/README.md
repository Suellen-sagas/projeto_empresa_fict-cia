# BookSpace — Sprint 2 (N2)

Projeto HTML/CSS original com JavaScript adicionado.

## Como executar
Abra esta pasta no VS Code e use **Live Server** em `index.html` (localhost). Primeiro cadastre uma conta fictícia.

## Funcionalidades
- Cadastro com validação e login local demonstrativo;
- Catálogo com pesquisa, filtro de gênero e detalhes específicos de cada livro;
- Carrinho: adicionar e remover livros;
- Aluguéis (CRUD): criar na finalização, ler a lista, atualizar status de devolução e excluir histórico devolvido;
- Editar dados da conta;
- Dados locais separados por usuário (`localStorage`);
- Responsividade extra e menu móvel.

## Arquivos
`script.js`: lógica; `sprint2.css`: estilos adicionais; páginas HTML: scripts e CSS conectados.

## Limitações
Protótipo acadêmico. `localStorage` pode ser apagado pelo navegador; não use senhas reais. O hash no navegador não fornece autenticação segura. Para produção, usar backend e autenticação. Livro Harry Potter fica indisponível por decisão do catálogo.

## Git / commits
Cada integrante deve fazer seus próprios commits reais. Sugestões de escopos: `feat: validacao cadastro`, `feat: catalogo dinamico`, `feat: carrinho local`, `feat: crud alugueis`, `style: responsividade`, `docs: atualiza README`. Não foram inventados commits.

## Teste manual
1. Cadastro com e-mail inválido e senha divergente deve falhar.
2. Cadastrar usuário e fazer login com senha errada (deve falhar), depois correta.
3. Buscar e filtrar livros; abrir detalhes de livros distintos.
4. Adicionar ao carrinho, remover, adicionar novamente, finalizar aluguel.
5. Marcar devolvido, excluir registro, editar conta e sair.
6. Abrir em dimensões de celular pelo inspetor do navegador.
